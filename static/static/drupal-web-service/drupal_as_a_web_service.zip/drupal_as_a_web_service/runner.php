<?php
include('Services_Drupal.php');
$s = new Services_Drupal('xmlrpc', 'XM1p4$$', 'localhost', 'bbcb58febc34fa9a69888b6e9aaaed0c', 'example');
//$node = $s->node_get(1);
//$nodes = $s->matching_by_fields(array('atxtfield:value' => 'foo'));
//$nodes = $s->matching_by_fields(array('anint:value' => 9));
$nodes = $s->matching_by_fields(array('atxtfield:value' => 'foo', 'anint:value' => 2));

//var_dump($node);
foreach ($nodes AS $n) {
    echo $n['title'] . "\n";
}
